<?php
/*
** Handset Detection - users.php - http://www.handsetdetection.com
** Create, edit, update, remove system users via API.
** Has some prerequsites - email hello@handsetdetectio for more info
*/

?>